import { Injectable } from '@angular/core';
import { Http } from '@capacitor-community/http';

export interface UserDataResponse {
  status: string;
  errorCode: string;
  message: string;
  result: any[];
}

@Injectable({
  providedIn: 'root'
})
export class RegisterService {

   private baseUrl = 'https://www.ayyappatelugu.com/APICalls/Users';

 async register(firstName: string, lastName: string, email: string, mobile: string, password: string,isIOS: string) {
  // ✅ Prepare key-value pairs like Postman form-data
  const data: any = {
    firstName: firstName,
    lastName: lastName,
    emailId: email,
    mobileNumber: mobile,
    isIOS: isIOS
  };

  // ✅ Only append password if user entered one
  if (password && password.trim() !== '') {
    data.pwd = password;
  }

  console.log('====================');
  console.log('REQUEST URL:', `${this.baseUrl}/userRegistration`);
  console.log('REQUEST DATA:', data);
  console.log('====================');

  try {
    // ✅ Send as multipart/form-data (same as Postman)
    const response = await Http.request({
      method: 'POST',
      url: `${this.baseUrl}/userRegistration`,
      headers: {
        'Content-Type': 'multipart/form-data',
      },
      data: data
    });

    console.log('➡️ API Raw Response:', response.data);

    // ✅ Normalize iOS string response
    const parsed =
      typeof response.data === 'string'
        ? JSON.parse(response.data)
        : response.data;

    console.log('✅ Parsed API Response:', parsed);
    return parsed as UserDataResponse;
  } catch (error) {
    console.error('❌ RegisterService Error:', error);
    throw error;
  }
}
// ==============================
  // DELETE ACCOUNT METHOD 
  // ==============================
  async deleteAccount(registerId: string) {

    const data = {
      registerId: registerId
    };

    try {
      const response = await Http.request({
        method: 'POST',
        url: `${this.baseUrl}/deleteUserAccount`,
        headers: { 'Content-Type': 'multipart/form-data' },
        data: data
      });

      console.log("➡️ Delete Raw Response:", response.data);

      const parsed =
        typeof response.data === 'string'
          ? JSON.parse(response.data)
          : response.data;

      console.log("✅ Parsed Delete Response:", parsed);

      return parsed;

    } catch (error) {
      console.error("❌ Delete API Error:", error);
      throw error;
    }
  }

  // ==============================
  // CHANGE PASSWORD 
  // ==============================

  async changePassword(registerId: string, currentPwd: string, newPwd: string) {

  const data = {
    registerId: registerId,
    cpwd: currentPwd,
    pwd: newPwd
  };

  try {
    const response = await Http.request({
      method: 'POST',
      url: `${this.baseUrl}/changePassword`,
      headers: {
        'Content-Type': 'multipart/form-data',
      },
      data: data
    });

    console.log("➡️ Change Password Raw:", response.data);

    const parsed =
      typeof response.data === 'string'
        ? JSON.parse(response.data)
        : response.data;

    console.log("✅ Parsed Change Password Response:", parsed);

    return parsed;

  } catch (error) {
    console.error("❌ Change Password API Error:", error);
    throw error;
  }
}
}